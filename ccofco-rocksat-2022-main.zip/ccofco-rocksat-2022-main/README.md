# ccofco-rocksat-2022
CC of CO RockSat 2021-2022 Payload Control Software

## Installation
On a fresh Raspian Lite installation on the Raspberry Pi, clone this folder to the pi user's home directory.
Make the cloned repository your working directory and then run the `install.sh` file with `$ sh install.sh`.
You will be prompted for the pi user's password as some aspects of the installer must run with elevated priveleges.

###### Notes for coders
- All files should have a blank newline at the end.
